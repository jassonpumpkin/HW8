public class ListNode {

  String key;
  int value;
  ListNode next;

  ListNode(String key, int value) {
    this.key = key;
    this.value = value;
    this.next = null;
  }

}
